local Chairs = {
	[0] = {Cost = 0,     Multiplier = 1.00, Slots = 1, Name="Broken Wood"},
	[1] = {Cost = 1000,  Multiplier = 1.05, Slots = 2, Name="Polished Wood"},
	[2] = {Cost = 4000,  Multiplier = 1.10, Slots = 2, Name="Bronze"},
	[3] = {Cost = 12000, Multiplier = 1.15, Slots = 3, Name="Iron"},
	[4] = {Cost = 35000, Multiplier = 1.20, Slots = 3, Name="Silver"},
}
return Chairs
