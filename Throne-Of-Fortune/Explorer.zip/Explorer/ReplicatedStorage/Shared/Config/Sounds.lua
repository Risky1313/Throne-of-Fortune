-- ReplicatedStorage/Shared/Config/Sounds.lua
return {
	UI = {
		Click   = "", -- rbxassetid://<your-id>
		Success = "",
		Error   = "",
	},
	Game = {
		Collect   = "",
		Flip      = "",
		SpinStart = "",
		SpinStop  = "",
		WinSmall  = "",
		WinBig    = "",
		Lose      = "",
	}
}
