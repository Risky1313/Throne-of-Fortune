return {
	AutoCollectGamepassId = 0,       -- put your Game Pass ID here
	AutoCollectIntervalSec = 10,     -- how often server auto-collects while player is online
}
