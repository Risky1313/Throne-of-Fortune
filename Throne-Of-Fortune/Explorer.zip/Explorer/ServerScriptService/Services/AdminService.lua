-- ServerScriptService/Services/AdminService.lua
-- AdminService v4d
-- Chips actions now update the authoritative data:
--  � Try EconomyService (common method names)
--  � Then try Profiles service (common getters; updates profile.Data.<Chips/Money/Balance>)
--  � Then leaderstats (IntValue/NumberValue)
--  � Then player attribute fallback
-- Keeps NoClip+Fly, Invisibility, Freeze, TPs.

local Players = game:GetService("Players")
local RS = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Remotes = RS:WaitForChild("Remotes")
local AdminFolder = Remotes:FindFirstChild("Admin") or Instance.new("Folder")
AdminFolder.Name = "Admin"
AdminFolder.Parent = Remotes

local AdminAction = AdminFolder:FindFirstChild("AdminAction") or Instance.new("RemoteFunction")
AdminAction.Name = "AdminAction"
AdminAction.Parent = AdminFolder

local ClientControl = AdminFolder:FindFirstChild("ClientControl") or Instance.new("RemoteEvent")
ClientControl.Name = "ClientControl"
ClientControl.Parent = AdminFolder

-- live config loader
local function loadAdminConfig()
	local Shared = RS:WaitForChild("Shared")
	local Config = Shared:WaitForChild("Config")
	local m = require(Config:WaitForChild("Admin"))
	local list = {}
	if m and type(m.AdminUserIds) == "table" then
		for _, uid in ipairs(m.AdminUserIds) do
			if typeof(uid) == "number" then table.insert(list, uid) end
		end
	end
	return list
end

local function isAuthorized(player)
	local whitelist = loadAdminConfig()
	for _, id in ipairs(whitelist) do
		if id == player.UserId then
			return true
		end
	end
	return false
end

-- Helpers
local function findPlayerByUserId(userId)
	for _, p in ipairs(Players:GetPlayers()) do
		if p.UserId == userId then return p end
	end
	return nil
end

-- Economy helpers
local function isNumberishValue(v)
	return v and (v:IsA("IntValue") or v:IsA("NumberValue"))
end

local function findChipsValue(player)
	local ls = player:FindFirstChild("leaderstats")
	if ls then
		for _, name in ipairs({"Chips","chips","Money","Cash","Balance"}) do
			local v = ls:FindFirstChild(name)
			if isNumberishValue(v) then
				return v
			end
		end
	end
	return nil
end

local function tryEconomyCall(methodNames, ...)
	local args = {...}
	local unpack = table.unpack or unpack
	local ok, Econ = pcall(function() return require(script.Parent:WaitForChild("EconomyService")) end)
	if not ok or (type(Econ) ~= "table" and type(Econ) ~= "userdata") then
		return false, "no economy module"
	end
	for _,mName in ipairs(methodNames) do
		local f = Econ[mName]
		if type(f)=="function" then
			-- try as method with self
			local ok1, res1 = pcall(function() return f(Econ, unpack(args)) end)
			if ok1 then return true, res1 end
			-- try as plain function
			local ok2, res2 = pcall(function() return f(unpack(args)) end)
			if ok2 then return true, res2 end
		end
	end
	return false, "no matching method"
end

-- Profiles integration
local function tryGetProfile(player)
	local ok, Profiles = pcall(function() return require(script.Parent:WaitForChild("Profiles")) end)
	if not ok or not Profiles then return nil end

	local candidates = {
		"GetProfile",
		"Get",
		"GetForPlayer",
		"GetProfileForPlayer",
		"GetProfileFromPlayer",
	}
	for _,fname in ipairs(candidates) do
		local fn = Profiles[fname]
		if type(fn)=="function" then
			local ok2, prof = pcall(function() return fn(Profiles, player) end)
			if ok2 and prof then return prof end
		end
	end

	-- Some services use a map table: Profiles[player] = profile
	if type(Profiles)=="table" and Profiles[player] then
		return Profiles[player]
	end

	return nil
end

local function setProfileChips(profile, amount, isDelta)
	if not profile then return false end
	local data = profile.Data or profile.data
	if type(data) ~= "table" then return false end
	local keys = {"Chips","chips","Money","money","Balance","balance"}
	for _,k in ipairs(keys) do
		if data[k] ~= nil then
			if isDelta then
				data[k] = (tonumber(data[k]) or 0) + (tonumber(amount) or 0)
			else
				data[k] = tonumber(amount) or 0
			end
			return true
		end
	end
	-- Create Chips if nothing matched
	if isDelta then
		data["Chips"] = (tonumber(data["Chips"]) or 0) + (tonumber(amount) or 0)
	else
		data["Chips"] = tonumber(amount) or 0
	end
	return true
end

local function clampToValueType(v, amount)
	if v:IsA("IntValue") then
		return math.floor(tonumber(amount) or 0)
	end
	return tonumber(amount) or 0
end

local function addChipsImpl(player, amount)
	amount = tonumber(amount) or 0
	if amount == 0 then return true end

	-- 1) EconomyService (authoritative in many games)
	local tried, _ = tryEconomyCall({"AddChips","addChips","GiveChips","giveChips","AdjustChips","adjustChips"}, player.UserId, amount)
	if tried then return true end
	tried, _ = tryEconomyCall({"AddChips","addChips","GiveChips","giveChips","AdjustChips","adjustChips"}, player, amount)
	if tried then return true end

	-- 2) Profiles (canonical data store)
	local prof = tryGetProfile(player)
	if prof then
		local okProf = setProfileChips(prof, amount, true)
		if okProf then
			-- mirror to leaderstats immediately
			local chips = findChipsValue(player)
			if chips then chips.Value = clampToValueType(chips, (chips.Value or 0) + amount) end
			return true
		end
	end

	-- 3) Leaderstats fallback
	local chips = findChipsValue(player)
	if chips then chips.Value = clampToValueType(chips, (chips.Value or 0) + amount); return true end

	-- 4) Attribute fallback
	player:SetAttribute("Chips", (player:GetAttribute("Chips") or 0) + amount)
	return true
end

local function setChipsImpl(player, amount)
	amount = tonumber(amount) or 0

	-- 1) EconomyService
	local tried, _ = tryEconomyCall({"SetChips","setChips"}, player.UserId, amount)
	if tried then return true end
	tried, _ = tryEconomyCall({"SetChips","setChips"}, player, amount)
	if tried then return true end

	-- 2) Profiles
	local prof = tryGetProfile(player)
	if prof then
		local okProf = setProfileChips(prof, amount, false)
		if okProf then
			local chips = findChipsValue(player)
			if chips then chips.Value = clampToValueType(chips, amount) end
			return true
		end
	end

	-- 3) Leaderstats fallback
	local chips = findChipsValue(player)
	if chips then chips.Value = clampToValueType(chips, amount); return true end

	-- 4) Attribute fallback
	player:SetAttribute("Chips", amount)
	return true
end

-- Invisibility
local function setInvisibility(targetPlayer, enabled)
	local char = targetPlayer and targetPlayer.Character
	if not char then return false, "no character" end
	targetPlayer:SetAttribute("AdminInvisible", enabled and true or false)
	for _, d in ipairs(char:GetDescendants()) do
		if d:IsA("BasePart") then
			if d.Name == "HumanoidRootPart" then
				d.Transparency = 1
			else
				d.Transparency = enabled and 1 or 0
			end
		elseif d:IsA("Decal") then
			d.Transparency = enabled and 1 or 0
		elseif d:IsA("ParticleEmitter") or d:IsA("Trail") then
			d.Enabled = not enabled
		end
	end
	local hum = char:FindFirstChildOfClass("Humanoid")
	if hum then
		if enabled then
			hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		else
			hum.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.Viewer
		end
	end
	return true
end

-- NoClip + Fly combo
local noclipLoops = {} -- [player] = RBXScriptConnection
local function enableNoClip(p)
	if noclipLoops[p] then return end
	local conn = RunService.Stepped:Connect(function()
		local char = p.Character
		if not char then return end
		for _, part in ipairs(char:GetDescendants()) do
			if part:IsA("BasePart") then
				part.CanCollide = false
			end
		end
	end)
	noclipLoops[p] = conn
end
local function disableNoClip(p)
	local conn = noclipLoops[p]
	if conn then conn:Disconnect(); noclipLoops[p] = nil end
	local char = p.Character
	if char then
		for _, part in ipairs(char:GetDescendants()) do
			if part:IsA("BasePart") then
				part.CanCollide = true
			end
		end
	end
end
Players.PlayerRemoving:Connect(function(p) disableNoClip(p) end)

local function setNoClipAndFly(targetPlayer, enabled)
	targetPlayer:SetAttribute("AdminNoClip", enabled and true or false)
	if enabled then enableNoClip(targetPlayer) else disableNoClip(targetPlayer) end
	ClientControl:FireClient(targetPlayer, { cmd = "fly", enabled = enabled })
	return true
end

-- Restore states on respawn
local function onCharacterAdded(p, _char)
	if p:GetAttribute("AdminInvisible") then setInvisibility(p, true) end
	if p:GetAttribute("AdminNoClip") then enableNoClip(p); ClientControl:FireClient(p, { cmd = "fly", enabled = true }) end
end
Players.PlayerAdded:Connect(function(p) p.CharacterAdded:Connect(function(char) onCharacterAdded(p, char) end) end)

-- ACTIONS
local function okStub() return true end

local ACTIONS = {
	ping = function(caller) return true end,
	getExploitSummary = function(caller) return true, { data = { totalLogs = 0, users = {} } } end,

	-- Movement & visibility
	freeze = function(caller, payload)
		local p = findPlayerByUserId(tonumber(payload.userId)); if not p then return false, "player not found" end
		local char = p.Character; if not char then return false, "no character" end
		local hum = char:FindFirstChildOfClass("Humanoid"); if not hum then return false, "no humanoid" end
		hum.WalkSpeed = payload.enabled and 0 or 16
		hum.JumpPower = payload.enabled and 0 or 50
		return true
	end,
	invisibility = function(caller, payload)
		local p = findPlayerByUserId(tonumber(payload.userId)); if not p then return false, "player not found" end
		return setInvisibility(p, payload.enabled and true or false)
	end,
	noclip = function(caller, payload)
		local p = findPlayerByUserId(tonumber(payload.userId)); if not p then return false, "player not found" end
		return setNoClipAndFly(p, payload.enabled and true or false)
	end,
	tpToPlayer = function(caller, payload)
		local target = findPlayerByUserId(tonumber(payload.userId)); if not target then return false, "player not found" end
		local callerChar = caller.Character; local targetChar = target.Character
		if not callerChar or not targetChar then return false, "character missing" end
		local hrp1 = callerChar:FindFirstChild("HumanoidRootPart"); local hrp2 = targetChar:FindFirstChild("HumanoidRootPart")
		if not hrp1 or not hrp2 then return false, "hrp missing" end
		hrp1.CFrame = hrp2.CFrame + Vector3.new(0, 3, 0)
		return true
	end,
	tpToMe = function(caller, payload)
		local target = findPlayerByUserId(tonumber(payload.userId)); if not target then return false, "player not found" end
		local callerChar = caller.Character; local targetChar = target.Character
		if not callerChar or not targetChar then return false, "character missing" end
		local hrp1 = callerChar:FindFirstChild("HumanoidRootPart"); local hrp2 = targetChar:FindFirstChild("HumanoidRootPart")
		if not hrp1 or not hrp2 then return false, "hrp missing" end
		hrp2.CFrame = hrp1.CFrame + Vector3.new(0, 3, 0)
		return true
	end,

	-- Economy
	addChips = function(caller, payload)
		local uid = tonumber(payload.userId); local amt = tonumber(payload.amount)
		if not uid or not amt then return false, "bad args" end
		local p = findPlayerByUserId(uid); if not p then return false, "player not found" end
		return addChipsImpl(p, amt)
	end,
	setChips = function(caller, payload)
		local uid = tonumber(payload.userId); local amt = tonumber(payload.amount)
		if not uid or amt==nil then return false, "bad args" end
		local p = findPlayerByUserId(uid); if not p then return false, "player not found" end
		return setChipsImpl(p, amt)
	end,
	resetChips = function(caller, payload)
		local uid = tonumber(payload.userId); if not uid then return false, "bad args" end
		local p = findPlayerByUserId(uid); if not p then return false, "player not found" end
		return setChipsImpl(p, 0)
	end,

	-- Utilities placeholders
	giveItem = okStub,
	givePrinter = okStub,
	startEvent = okStub,
	giveKey = okStub,

	-- Moderation placeholders
	banTemp = okStub,
	banPerm = okStub,
	unban = okStub,
}

-- Dispatcher (auth every call)
AdminAction.OnServerInvoke = function(player, action, payload)
	if not isAuthorized(player) then
		return { ok = false, err = "not authorized" }
	end
	local fn = ACTIONS[action]
	if not fn then
		return { ok = false, err = "unknown action: "..tostring(action) }
	end
	local ok, resOrErr = fn(player, payload or {})
	if ok == true then
		return { ok = true, data = resOrErr }
	else
		return { ok = false, err = resOrErr or "error" }
	end
end

return true
