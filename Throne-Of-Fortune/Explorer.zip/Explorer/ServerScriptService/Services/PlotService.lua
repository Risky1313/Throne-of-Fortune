local Players = game:GetService("Players")
local RS      = game:GetService("ReplicatedStorage")
local WS      = game:GetService("Workspace")

local Profiles   = require(script.Parent.Profiles)
local ChairsCfg  = require(RS.Shared.Config.Chairs)
local PrintersCfg= require(RS.Shared.Config.Printers)

local Signals = RS:WaitForChild("Signals")
local RebuildPlotBE = Signals:WaitForChild("RebuildPlot") :: BindableEvent

local PLOTS_FOLDER = (function()
	local f = WS:FindFirstChild("Plots")
	if not f then f = Instance.new("Folder"); f.Name = "Plots"; f.Parent = WS end
	return f
end)()

-- simple placement grid (X-spaced)
local function plotCFrameFor(index)
	local spacing = 80
	local x = (index - 1) * spacing
	return CFrame.new(x, 2, 0)
end

-- find index for player (stable order by UserId)
local function indexFor(plr)
	local ids = {}
	for _, p in ipairs(Players:GetPlayers()) do table.insert(ids, p.UserId) end
	table.sort(ids)
	for i, id in ipairs(ids) do if id == plr.UserId then return i end end
	return 1
end

local function clearChildren(inst, predicate)
	for _, c in ipairs(inst:GetChildren()) do
		if not predicate or predicate(c) then c:Destroy() end
	end
end

local function mkBillboard(parent, text)
	local bb = Instance.new("BillboardGui")
	bb.Size = UDim2.new(0, 200, 0, 50)
	bb.StudsOffset = Vector3.new(0, 3, 0)
	bb.AlwaysOnTop = true
	bb.Adornee = parent
	bb.Parent = parent
	local tl = Instance.new("TextLabel")
	tl.BackgroundTransparency = 1
	tl.Size = UDim2.new(1, 0, 1, 0)
	tl.Font = Enum.Font.GothamBold
	tl.TextScaled = true
	tl.TextColor3 = Color3.new(1,1,1)
	tl.TextStrokeTransparency = 0.6
	tl.Text = text
	tl.Parent = bb
	return bb, tl
end

local function mkBase(parent)
	local base = Instance.new("Part")
	base.Name = "Base"
	base.Size = Vector3.new(24, 1, 24)
	base.Anchored = true
	base.Material = Enum.Material.SmoothPlastic
	base.Color = Color3.fromRGB(35, 40, 45)
	base.Parent = parent
	return base
end

local function mkThrone(parent, tier)
	local throne = Instance.new("Part")
	throne.Name = "Throne"
	throne.Size = Vector3.new(4, 5, 4)
	throne.Anchored = true
	throne.Material = Enum.Material.Metal
	local colorByTier = {
		[0]=Color3.fromRGB(120, 90, 60), -- wood
		[1]=Color3.fromRGB(170, 170, 170),
		[2]=Color3.fromRGB(200, 215, 255),
		[3]=Color3.fromRGB(255, 215, 0),
	}
	throne.Color = colorByTier[tier] or Color3.fromRGB(255, 230, 120)
	throne.Parent = parent

	local _, tl = mkBillboard(throne, ("Chair Tier %d"):format(tier))
	tl.Text = ("Chair Tier %d"):format(tier)

	return throne
end

local function mkPrinter(parent, slot, cfg, stored, capacity)
	local p = Instance.new("Part")
	p.Name = ("Printer_%d"):format(slot)
	p.Size = Vector3.new(2.2, 2, 2.2)
	p.Anchored = true
	p.Material = Enum.Material.Neon
	p.Color = Color3.fromRGB(60, 120, 200)
	p.Parent = parent
	local _, tl = mkBillboard(p, ("%s | %d/%d"):format(cfg.Display or cfg.Name or ("P"..slot), math.floor(stored or 0), capacity or 0))

	-- Attach printer slot attribute and interaction prompt
	p:SetAttribute("Slot", slot)
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "PrinterInteract"
	prompt.ActionText = "Collect (Press E) / Sell (Hold R)"
	prompt.ObjectText = cfg.Display or (cfg.Name or ("Printer "..tostring(slot)))
	prompt.KeyboardKeyCode = Enum.KeyCode.R
	prompt.HoldDuration = 4
	prompt.MaxActivationDistance = 12
	prompt.RequiresLineOfSight = false
	prompt.Parent = p
	return p
end

local function buildPlot(plr)
	local profile = Profiles.Get(plr); if not profile or not profile.Data then return end
	local d = profile.Data
	d.Printers = d.Printers or {}

	-- get or create model
	local modelName = tostring(plr.UserId)
	local m = PLOTS_FOLDER:FindFirstChild(modelName)
	if not m then m = Instance.new("Model"); m.Name = modelName; m.Parent = PLOTS_FOLDER end

	-- wipe previous children
	clearChildren(m)

	-- place base + throne
	local index = indexFor(plr)
	local cf = plotCFrameFor(index)
	local base = mkBase(m); base.CFrame = cf * CFrame.new(0, 0, 0)
	local tier = (d.Chair and d.Chair.Tier) or 0
	local throne = mkThrone(m, tier); throne.CFrame = cf * CFrame.new(0, 3, -6)

	-- printer pads (arrange in a row)
	local n = #d.Printers
	local startX = -(math.max(1, n) - 1) * 3
	for i, pr in ipairs(d.Printers) do
		local cfg = PrintersCfg[pr.Id] or { Display = pr.Id, Capacity = pr.Capacity }
		local part = mkPrinter(m, i, cfg, pr.Stored, pr.Capacity)
		part.CFrame = cf * CFrame.new(startX + (i-1)*6, 2, 3)
	end
end

-- Lightweight periodic label updater (keeps billboard text fresh)
local function updateLabels(plr)
	local profile = Profiles.Get(plr); if not profile or not profile.Data then return end
	local d = profile.Data
	local model = PLOTS_FOLDER:FindFirstChild(tostring(plr.UserId)); if not model then return end

	-- throne label
	local throne = model:FindFirstChild("Throne")
	if throne and throne:FindFirstChildOfClass("BillboardGui") then
		local tl = throne.BillboardGui:FindFirstChildOfClass("TextLabel")
		if tl then
			local tier = (d.Chair and d.Chair.Tier) or 0
			tl.Text = ("Chair Tier %d"):format(tier)
		end
	end

	-- printer labels
	for _, pr in ipairs(d.Printers) do
		local node = model:FindFirstChild(("Printer_%d"):format(pr.Slot or 0))
		if node and node:FindFirstChildOfClass("BillboardGui") then
			local tl = node.BillboardGui:FindFirstChildOfClass("TextLabel")
			if tl then
				local cfg = PrintersCfg[pr.Id] or {}
				tl.Text = ("%s | %d/%d"):format(cfg.Display or pr.Id, math.floor(pr.Stored or 0), pr.Capacity or 0)
			end
		end
	end
end

-- Reactions -------------------------------------------------------------------
Players.PlayerAdded:Connect(function(plr)
	task.defer(function() buildPlot(plr) end)
end)

Players.PlayerRemoving:Connect(function(plr)
	local m = PLOTS_FOLDER:FindFirstChild(tostring(plr.UserId))
	if m then m:Destroy() end
end)

-- External rebuild trigger (called by other services when something changes)
RebuildPlotBE.Event:Connect(function(userId)
	local plr = Players:GetPlayerByUserId(userId)
	if plr then buildPlot(plr) end
end)

-- Periodic UI label refresh
task.spawn(function()
	while true do
		task.wait(1.5)
		for _, plr in ipairs(Players:GetPlayers()) do
			updateLabels(plr)
		end
	end
end)

return {}
